package com.cts.modal;

public class FlightSearch {

	private String source;
	private String destination;
	private String dateOfJournay;
	private int noOfPassengers;
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDateOfJournay() {
		return dateOfJournay;
	}
	public void setDateOfJournay(String dateOfJournay) {
		this.dateOfJournay = dateOfJournay;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	@Override
	public String toString() {
		return "FlightSearch [source=" + source + ", destination=" + destination + ", dateOfJournay=" + dateOfJournay
				+ ", noOfPassengers=" + noOfPassengers + "]";
	}
	
	
}
