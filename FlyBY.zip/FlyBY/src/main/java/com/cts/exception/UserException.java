package com.cts.exception;

public class UserException extends Exception{

	public UserException(String message) {
		super(message);
	}

}
