package com.cts.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="passenger")

@NamedQuery(name="getPassengerDetail", query="from Passenger P where P.passengerId =:passengerId")

public class Passenger {
	
	@Column(name="passengerId")
	private int passengerId;

	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public Flight getFlight() {
		return flight;
	}
	public Passenger() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Passenger(String passengerName, long contactNumber, String email, int bookingId, Flight flight) {
		super();
		this.passengerName = passengerName;
		this.contactNumber = contactNumber;
		this.email = email;
		this.bookingId = bookingId;
		this.flight = flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	@Column(name="passengerName")
	private String passengerName;
	@Column(name="contactNumber")
	private long contactNumber;
	@Column(name="email")
	private String email;
	
	@Transient
	private int noOfPassengers;
	
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	@Id
	@GeneratedValue
	private int bookingId;
	
	@OneToOne
	@JoinColumn(name="flight_Id")
	private Flight flight;
	
	public int getPassengerId() {
		return passengerId;
	}
	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	
	public long getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Passenger [passengerId=" + passengerId + ", passengerName=" + passengerName + ", contactNumber="
				+ contactNumber + ", email=" + email + ", bookingId=" + bookingId + ", flight=" + flight + "]";
	}

	

}
