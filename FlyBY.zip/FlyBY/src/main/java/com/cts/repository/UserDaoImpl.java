package com.cts.repository;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.entity.Flight;
import com.cts.entity.User;
import com.cts.exception.UserException;

@Repository
@Transactional
public class UserDaoImpl implements UserDao {

	@Autowired
	private EntityManager manager;
	
	
	public boolean saveUser(User user) throws UserException{
		// TODO Auto-generated method stub
		
		boolean flag =true;
		User current_user = checkUserNameAndEmail(user);
			if(current_user!=null) {
				if(current_user.getUserName().equalsIgnoreCase(user.getUserName())) {
					flag = false;
					throw new UserException("UserName already Exists");
				}
				else if(current_user.getEmail().equalsIgnoreCase(user.getEmail())) {
					flag = false;
					throw new UserException("Email already exists");
				}
			}
			else {
			manager.persist(user);
			}
		
		return flag;
	}

	@Override
	public boolean deleteUser(int userId) {
		// TODO Auto-generated method stub
		User user = getUserDetails(userId);
		System.out.println("deleting User :" + user);
		manager.remove(user);
		return true;
	}

	@Override
	public boolean updateUser(User user) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public User getUserDetails(int userId) {
		// TODO Auto-generated method stub
		Query query=manager.createNamedQuery("getUserDetail");
		query.setParameter("Id", userId);
		return (User) query.getSingleResult();
	}


	@Override
	public User checkUserNameAndEmail(User user){
		
		Query checkUserNameAndEmail = manager.createNamedQuery("userNameAndEmail");
		checkUserNameAndEmail.setParameter("userName", user.getUserName());
		checkUserNameAndEmail.setParameter("email", user.getEmail());
		User existedUser=null;
		try {
		existedUser = (User) checkUserNameAndEmail.getSingleResult();
		}catch(Exception e) {
			System.out.println("UserDao Imol checkUserNameANdEmail   \t"+e.getMessage());
		}
		
		return existedUser;
	}


	@Override
	public User checkUserCredentials(User user) {
		// TODO Auto-generated method stub
		Query query=manager.createNamedQuery("chekcUserCredentilas");
		query.setParameter("userName", user.getUserName());
		query.setParameter("password", user.getPassword());
		User querryUser=null;
		try {
		querryUser = (User) query.getSingleResult();
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}
		
		return querryUser;
	}
	
	

}
