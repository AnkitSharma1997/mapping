package com.cts.repository;

import java.util.List;

import com.cts.entity.Flight;
import com.cts.entity.Passenger;
import com.cts.modal.FlightSearch;

public interface BookingDao {

	public boolean bookingFlight(Passenger passenger, int flightId, int noOfPassengers);
	public List<Passenger> bookingHistory(int userId);
	public List<Flight> searchCorrespondingFlights(FlightSearch searchObject);
	boolean saveFlight(Flight flight);
	boolean updateFlight(Flight flight);
	
}
