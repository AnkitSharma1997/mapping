package com.cts.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.entity.Flight;
import com.cts.entity.Passenger;
import com.cts.entity.User;
import com.cts.modal.FlightSearch;
@Repository
@Transactional
public class BookingDaoImpl implements BookingDao {

	@Autowired
	private EntityManager manager;
	
	@Override
	public boolean bookingFlight(Passenger passenger, int flightId, int noOfPassengers) {
		// TODO Auto-generated method stub
	
		Query flightList=manager.createNamedQuery("getFlightDetail");
		flightList.setParameter("fid", flightId);
		Flight bookingTheFlight = (Flight) flightList.getSingleResult();
		bookingTheFlight.setSeatsBooked((bookingTheFlight.getSeatsBooked() + noOfPassengers));
		updateFlight(bookingTheFlight);
		passenger.setFlight(bookingTheFlight);
		manager.persist(passenger);
		return true;
	}
	@Override
	public boolean saveFlight(Flight flight) {
		// TODO Auto-generated method stub
		System.out.println("MY Flight Info    :::::   "+ flight);
		
		manager.persist(flight);
		return false;
	}
	@Override
	public boolean updateFlight(Flight flight) {
		// TODO Auto-generated method stub
		System.out.println("MY flight Info    :::::   "+ flight);
		try {
		manager.merge(flight);
		}catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return false;
	}
	@Override
	public List<Passenger> bookingHistory(int userId) {
		// TODO Auto-generated method stub
		Query query=manager.createNamedQuery("getPassengerDetail");
		query.setParameter("passengerId", userId);
		List<Passenger> passenger =  query.getResultList();
		return passenger;
	}

	@Override
	public List<Flight> searchCorrespondingFlights(FlightSearch searchObject) {
		// TODO Auto-generated method stub
		Query query=manager.createNamedQuery("searchFlights");
		query.setParameter("source", searchObject.getSource());
		query.setParameter("destination", searchObject.getDestination());
		query.setParameter("dateOfJourney", searchObject.getDateOfJournay());
		List<Flight> flights =  query.getResultList();
		
		
		return flights;
	}
	

}
