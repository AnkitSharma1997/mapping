package com.cts.controllers;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.cts.entity.Address;
import com.cts.entity.Flight;
import com.cts.entity.Passenger;
import com.cts.entity.User;
import com.cts.exception.UserException;
import com.cts.modal.FlightSearch;
import com.cts.service.Booking;
import com.cts.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService service;
	
	@Autowired
	public HttpSession session;
	
	@Autowired
	private Booking bookingService;
	
	@RequestMapping("/")
	public String userLoginPage() {
		return "login";
	}
	
	@RequestMapping("/userRegistration")
	public String userRegistration() {
		return "userRegistration";
	}
	
	private int flightId;
	private int noOfPassengers;
	
	@RequestMapping("/welcome")
	public ModelAndView userWelcomePage(@ModelAttribute("user") User user) {
		ModelAndView mv = new ModelAndView();
		User user_current= service.checkUserCredentials(user);
		if(user_current !=null) {
			mv.setViewName("welcome");
			session.setAttribute("userName", user_current.getUserName());
			session.setAttribute("userId", user_current.getUserId());
			session.setAttribute("password", user_current.getPassword());
			}
		else {
			mv.setViewName("login");
			mv.addObject("status", "Sorry! Incorrect UserName and Password");
		}
		return mv;
	}
	
	
	@RequestMapping("/saveUserDetail")
	public ModelAndView saveUser(@ModelAttribute("user") User user, HttpServletRequest request) throws UserException {
		ModelAndView mv = new ModelAndView();
		String[] address = request.getParameterValues("city");
		Address address1 = new Address();
		address1.setCity(address[0]);
		Address address2 = new Address();
		address2.setCity(address[1]);
	
		user.addAddress(address1);
		user.addAddress(address2);
		String errorMessage= service.saveUser(user);
		if(errorMessage!=null) {
			mv.setViewName("userRegistration");
			mv.addObject("errorMessage", errorMessage);
		}
		else{
			mv.setViewName("login");
		}
		return mv;
	}
	
	@RequestMapping("getUserDetails")
	public ModelAndView getUserDetails() {
		ModelAndView mv= new ModelAndView();
		User user = service.getUserDetails((int)session.getAttribute("userId"));
		List<Address> addressList = user.getAddress();
		mv.addObject("userDetail", user);
		mv.addObject("addressList", addressList);
		mv.setViewName("userDetails");
		return mv;
	}
	

	@ResponseBody
	@RequestMapping("/saveFlightDetail")
	public String saveFlight() {
		Flight flight = new Flight();
		flight.setFlightName("KingFisher");
		flight.setSource("Pune");
		flight.setDestination("Banglore");
		flight.setFare(2587.0);
		flight.setSeatsAvailable(300);
		flight.setDateOfJourney("2020-03-26");
		flight.setTimeOfArrival("23:40");
		flight.setTimeOfDeparture("21:20");
		flight.setSeatsBooked(0);
		
		if(bookingService.saveFlight(flight))
			return "Not Saved";
		
		return "sucess";
	}
	
	@RequestMapping("/bookingFlight")
	public ModelAndView bookingFlight(@ModelAttribute("passenger") Passenger passenger){
		ModelAndView mv = new ModelAndView();
		System.out.println("flightId \t"+this.flightId+"\t passenger \t"+ passenger);
		passenger.setPassengerId((int) session.getAttribute("userId"));
		if(bookingService.bookingFlight(passenger, this.flightId, this.noOfPassengers))
			mv.setViewName("welcome");
		return mv;
	}
	
	@RequestMapping("/bookingHistory")
	public ModelAndView bookingHistory(){
		List<Passenger> passenger = bookingService.bookingHistory((int)session.getAttribute("userId"));
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("bookingHistory");
		mv.addObject("bookingHistoryList", passenger);
		return mv;
	}
	
	@RequestMapping("/searchFlight")
	public ModelAndView searchFlight(){
		ModelAndView mv = new ModelAndView();
		
		mv.setViewName("searchFlight");
		
		return mv;
	}
	
	@RequestMapping("/searchDetails")
	public ModelAndView flightDetails(@ModelAttribute("search") FlightSearch searchObject, HttpServletRequest request){
		ModelAndView mv = new ModelAndView();
		noOfPassengers =Integer.parseInt(request.getParameter("noOfPassengers"));
		System.out.println("my searchObject \t "+ searchObject);
		List<Flight> flightsList = bookingService.searchCorrespondingFlights(searchObject);
		mv.setViewName("flightDetails");
		mv.addObject("listOfFlights", flightsList);
		return mv;
	}
	
	@RequestMapping("/passengerDetail")
	public ModelAndView passengerDetail(@RequestParam("flightId") int flightId) {
		ModelAndView mv = new ModelAndView();
		this.flightId = flightId;
		mv.setViewName("passengerDetail");
		mv.addObject("flightId", flightId);
		return mv;
	}
	
	@RequestMapping("/logOut")
	public ModelAndView logOut() {
		ModelAndView mv = new ModelAndView();
		session.removeAttribute("userName");
		session.removeAttribute("password");
		session.removeAttribute("userId");
		mv.setViewName("login");
		return mv;
	}
	
	@ModelAttribute("user")
	public User userObject() {
		User user = new User();
		return user;
	}
	
	
	@ModelAttribute("search")
	public FlightSearch flightSearchObject(){
		FlightSearch searchObject = new FlightSearch();
		return searchObject;
	}
	
	@ModelAttribute("passenger")
	public Passenger passengerObject() {
		Passenger passenger = new Passenger();
		return passenger;
	}
	
	@ModelAttribute("flight")
	public Flight flightObject() {
		Flight flightObject = new Flight();
		return flightObject;
	}
}
