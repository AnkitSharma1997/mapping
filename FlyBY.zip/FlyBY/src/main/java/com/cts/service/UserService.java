package com.cts.service;

import com.cts.entity.Flight;
import com.cts.entity.User;
import com.cts.exception.UserException;

public interface UserService {

	public String saveUser(User user);
	public boolean deleteUser(int userId);
	public boolean updateUser(User user);
	public User getUserDetails(int userId);
	public User checkUserCredentials(User user);
}
